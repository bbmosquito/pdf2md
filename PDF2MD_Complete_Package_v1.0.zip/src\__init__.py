"""
PDF2MD - Large PDF to Markdown Converter

A tool for converting large scanned PDFs to Markdown format,
optimized for files >200MB with memory-efficient processing.
"""

__version__ = "0.1.0"
__author__ = "PDF2MD Team"
